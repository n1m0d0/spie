<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__env->slot('table'); ?>
            <div class="overflow-x-auto relative shadow-md sm:rounded-lg">
                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Code')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Type')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Sector')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Pillar')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Hub')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Goal')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Result')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Action')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Result description')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Action description')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Indicator')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Territory')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('Finance')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <?php echo e(__('State')); ?>

                            </th>

                            <th scope="col" class="py-3 px-6">
                                <span class="sr-only">Options</span>
                            </th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php
                            $visibility = false;
                        ?>

                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <th scope="row"
                                class="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                <?php echo e($planning->code); ?>

                            </th>

                            <td class="py-4 px-6">
                                <ul>
                                    <?php $__currentLoopData = $planning->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="flex items-center gap-2">
                                            <?php echo e($type->name); ?>

                                        </li>

                                        <?php
                                            if ($type->id == 9 || $type->id == 10 || $type->id == 11) {
                                                $visibility = true;
                                            }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->sector->name); ?> <?php echo e($planning->sector->description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php $__currentLoopData = $planning->action->result->goal->hub->pillars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400">
                                        <li>
                                            <?php echo e($pilar->name); ?> <?php echo e($pilar->description); ?>

                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->action->result->goal->hub->name); ?>

                                <?php echo e($planning->action->result->goal->hub->description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->action->result->goal->name); ?>

                                <?php echo e($planning->action->result->goal->description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->action->result->name); ?> <?php echo e($planning->action->result->description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->action->name); ?> <?php echo e($planning->action->description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->result_description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php echo e($planning->action_description); ?>

                            </td>

                            <td class="py-4 px-6">
                                <?php $__currentLoopData = $planning->indicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400">
                                        <li>
                                            <?php echo e($indicator->description); ?>


                                            <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                                <?php echo e(__('Schedule')); ?>

                                            </h1>

                                            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                                <thead
                                                    class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                                    <tr>
                                                        <?php $__currentLoopData = $indicator->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th scope="col" class="py-3 px-6">
                                                                <?php echo e($schedule->date); ?>

                                                            </th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                        <?php $__currentLoopData = $indicator->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="py-4 px-6">
                                                                <?php echo e($schedule->description); ?>

                                                            </td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td class="py-4 px-6">
                                <?php $__currentLoopData = $planning->territories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $territory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400">
                                        <li>
                                            <?php echo e($territory->municipality->department->name); ?>

                                            <?php echo e($territory->municipality->name); ?>

                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td class="py-4 px-6">
                                <?php $__currentLoopData = $planning->finances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400">
                                        <li>
                                            <p>
                                                <?php echo e(__('Programmatic Category')); ?>:
                                                <?php echo e($finance->programmatic_category); ?>

                                                <br>
                                                <?php echo e(__('Budget')); ?>: <?php echo e($finance->budget); ?>

                                            </p>

                                            <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                                <?php echo e(__('Consolidated')); ?></h1>

                                            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                                <thead
                                                    class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                                    <tr>
                                                        <?php $__currentLoopData = $finance->consolidateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consolidated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <th scope="col" class="py-3 px-6">
                                                                <?php echo e($consolidated->date); ?>

                                                            </th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                        <?php $__currentLoopData = $finance->consolidateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consolidated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td class="py-4 px-6">
                                                                <?php echo e($consolidated->budget); ?>

                                                            </td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </tbody>
                                            </table>

                                            <?php if($visibility): ?>
                                                <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                                    <?php echo e(__('Investment')); ?></h1>

                                                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                                    <thead
                                                        class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                                        <tr>
                                                            <?php $__currentLoopData = $finance->investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <th scope="col" class="py-3 px-6">
                                                                    <?php echo e($investment->date); ?>

                                                                </th>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                            <?php $__currentLoopData = $finance->investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td class="py-4 px-6">
                                                                    <?php echo e($investment->budget); ?>

                                                                </td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                                    <?php echo e(__('Current')); ?></h1>

                                                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                                    <thead
                                                        class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                                        <tr>
                                                            <?php $__currentLoopData = $finance->currents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <th scope="col" class="py-3 px-6">
                                                                    <?php echo e($current->date); ?>

                                                                </th>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                    </thead>

                                                    <tbody>
                                                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                            <?php $__currentLoopData = $finance->currents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <td class="py-4 px-6">
                                                                    <?php echo e($current->budget); ?>

                                                                </td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td class="py-4 px-6">
                                <ul>
                                    <?php if(is_null($planning->is_approved)): ?>
                                        <li class="text-yellow-400"><?php echo e(__('Pending')); ?></li>
                                    <?php endif; ?>
                                    <?php if($planning->is_approved == true): ?>
                                        <li class="text-green-400"><?php echo e(__('Approved')); ?></li>
                                    <?php endif; ?>
                                    <?php if($planning->is_approved == false): ?>
                                        <li class="text-orange-400"><?php echo e(__('Review')); ?></li>
                                    <?php endif; ?>
                                </ul>
                            </td>

                            <td class="py-4 px-6">
                                <ul>
                                    <li>
                                        <a wire:click='modalValidate(<?php echo e($planning->id); ?>)'
                                            class="font-medium text-green-600 dark:text-green-500 hover:underline cursor-pointer"><?php echo e(__('Validate')); ?></a>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('paginate'); ?>
        <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model' => 'validateModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'validateModal']); ?>
         <?php $__env->slot('title', null, []); ?> 
            <div class="flex col-span-6 sm:col-span-4 items-center">
                <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feathericon-alert-triangle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-10 w-10 text-blue-500 mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
                <?php echo e(__('Validate')); ?>

            </div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <div class="flex col-span-6 sm:col-span-4 items-center gap-2">
                <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feathericon-folder-plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-20 w-20 text-blue-500 mr-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
                <div class="relative z-0 mb-6 w-full group">
                    <select id="is_approved" wire:model="is_approved"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <option value=""><?php echo e(__('Select an option')); ?></option>
                        <option value="1"><?php echo e(__('Approved')); ?></option>
                        <option value="0"><?php echo e(__('Review')); ?></option>
                    </select>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.input-error','data' => ['for' => 'is_approved']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'is_approved']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.danger-button','data' => ['wire:click' => '$set(\'validateModal\', false)','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'validateModal\', false)','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__('Cancel')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.secondary-button','data' => ['class' => 'ml-2','wire:click' => 'validatePlanning','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-2','wire:click' => 'validatePlanning','wire:loading.attr' => 'disabled']); ?>
                <?php echo e(__('Accept')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH D:\ajatic\trabajos\spie\resources\views/livewire/component-show.blade.php ENDPATH**/ ?>