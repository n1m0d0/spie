<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-white leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('h2COMSi')) {
    $componentId = $_instance->getRenderedChildComponentId('h2COMSi');
    $componentTag = $_instance->getRenderedChildComponentTagName('h2COMSi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h2COMSi');
} else {
    $response = \Livewire\Livewire::mount('component-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('h2COMSi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-report-hub')->html();
} elseif ($_instance->childHasBeenRendered('aouerh4')) {
    $componentId = $_instance->getRenderedChildComponentId('aouerh4');
    $componentTag = $_instance->getRenderedChildComponentTagName('aouerh4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aouerh4');
} else {
    $response = \Livewire\Livewire::mount('component-report-hub');
    $html = $response->html();
    $_instance->logRenderedChild('aouerh4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-report-indicator')->html();
} elseif ($_instance->childHasBeenRendered('diXy7g7')) {
    $componentId = $_instance->getRenderedChildComponentId('diXy7g7');
    $componentTag = $_instance->getRenderedChildComponentTagName('diXy7g7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('diXy7g7');
} else {
    $response = \Livewire\Livewire::mount('component-report-indicator');
    $html = $response->html();
    $_instance->logRenderedChild('diXy7g7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-report-budget')->html();
} elseif ($_instance->childHasBeenRendered('UdAusEA')) {
    $componentId = $_instance->getRenderedChildComponentId('UdAusEA');
    $componentTag = $_instance->getRenderedChildComponentTagName('UdAusEA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UdAusEA');
} else {
    $response = \Livewire\Livewire::mount('component-report-budget');
    $html = $response->html();
    $_instance->logRenderedChild('UdAusEA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-report-dictum')->html();
} elseif ($_instance->childHasBeenRendered('hnsZlcH')) {
    $componentId = $_instance->getRenderedChildComponentId('hnsZlcH');
    $componentTag = $_instance->getRenderedChildComponentTagName('hnsZlcH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hnsZlcH');
} else {
    $response = \Livewire\Livewire::mount('component-report-dictum');
    $html = $response->html();
    $_instance->logRenderedChild('hnsZlcH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-report-actor')->html();
} elseif ($_instance->childHasBeenRendered('ASHidok')) {
    $componentId = $_instance->getRenderedChildComponentId('ASHidok');
    $componentTag = $_instance->getRenderedChildComponentTagName('ASHidok');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ASHidok');
} else {
    $response = \Livewire\Livewire::mount('component-report-actor');
    $html = $response->html();
    $_instance->logRenderedChild('ASHidok', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-900 overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component-report-municipality')->html();
} elseif ($_instance->childHasBeenRendered('UD8QpF9')) {
    $componentId = $_instance->getRenderedChildComponentId('UD8QpF9');
    $componentTag = $_instance->getRenderedChildComponentTagName('UD8QpF9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UD8QpF9');
} else {
    $response = \Livewire\Livewire::mount('component-report-municipality');
    $html = $response->html();
    $_instance->logRenderedChild('UD8QpF9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\ajatic\trabajos\spie\resources\views/dashboard.blade.php ENDPATH**/ ?>