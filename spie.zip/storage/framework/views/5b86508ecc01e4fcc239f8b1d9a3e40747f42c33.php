<table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
        <tr>
            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Code')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Entity')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Type')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Sector')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Pillar')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Hub')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Goal')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Result')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Action')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Result description')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Action description')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Indicator')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Territory')); ?>

            </th>

            <th scope="col" class="py-3 px-6">
                <?php echo e(__('Finance')); ?>

            </th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $plannings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $visibility = false;
            ?>

            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                <th scope="row" class="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                    <?php echo e($planning->code); ?>

                </th>

                <td class="py-4 px-6">
                    <?php echo e($planning->entity->name); ?>

                </td>

                <td class="py-4 px-6">
                    <ul>
                        <?php $__currentLoopData = $planning->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-center gap-2">
                                <?php echo e($type->name); ?>

                            </li>

                            <?php
                                if ($type->id == 9 || $type->id == 10 || $type->id == 11) {
                                    $visibility = true;
                                }
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->sector->name); ?> <?php echo e($planning->sector->description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php $__currentLoopData = $planning->action->result->goal->hub->pillars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400">
                            <li>
                                <?php echo e($pilar->name); ?> <?php echo e($pilar->description); ?>

                            </li>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->action->result->goal->hub->name); ?>

                    <?php echo e($planning->action->result->goal->hub->description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->action->result->goal->name); ?>

                    <?php echo e($planning->action->result->goal->description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->action->result->name); ?> <?php echo e($planning->action->result->description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->action->name); ?> <?php echo e($planning->action->description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->result_description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php echo e($planning->action_description); ?>

                </td>

                <td class="py-4 px-6">
                    <?php $__currentLoopData = $planning->indicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($indicator_type_id != null): ?>
                            <?php if($indicator->types->where('id', $indicator_type_id)->count() > 0): ?>
                                <?php echo e($indicator->description); ?>


                                <br>

                                <h1 class="text-lg m-2 text-gray-900 dark:text-white"><?php echo e(__('Schedule')); ?>

                                </h1>

                                <ul
                                    class="flex flex-wrap items-center justify-center mb-6 text-gray-900 dark:text-white">
                                    <?php $__currentLoopData = $indicator->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($schedule->date); ?> => <?php echo e($schedule->description); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php echo e($indicator->description); ?>


                            <br>

                            <h1 class="text-lg m-2 text-gray-900 dark:text-white"><?php echo e(__('Schedule')); ?>

                            </h1>

                            <ul class="flex flex-wrap items-center justify-center mb-6 text-gray-900 dark:text-white">
                                <?php $__currentLoopData = $indicator->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($schedule->date); ?> => <?php echo e($schedule->description); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td class="py-4 px-6">
                    <?php $__currentLoopData = $planning->territories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $territory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul>
                            <li>
                                <?php echo e($territory->municipality->department->name); ?>

                                <br>
                                <?php echo e($territory->municipality->name); ?>

                            </li>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td class="py-4 px-6">
                    <?php $__currentLoopData = $planning->finances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400">
                            <li>
                                <p>
                                    <?php echo e(__('Programmatic Category')); ?>:
                                    <?php echo e($finance->programmatic_category); ?>

                                    <br>
                                    <?php echo e(__('Budget')); ?>: <?php echo e($finance->budget); ?>

                                </p>

                                <br>

                                <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                    <?php echo e(__('Consolidated')); ?></h1>

                                <ul
                                    class="flex flex-wrap items-center justify-center mb-6 text-gray-900 dark:text-white">
                                    <?php $__currentLoopData = $finance->consolidateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consolidated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($consolidated->date); ?> => <?php echo e($consolidated->budget); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                                <br>

                                <?php if($visibility): ?>
                                    <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                        <?php echo e(__('Investment')); ?></h1>

                                    <ul
                                        class="flex flex-wrap items-center justify-center mb-6 text-gray-900 dark:text-white">
                                        <?php $__currentLoopData = $finance->investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <?php echo e($investment->date); ?> => <?php echo e($investment->budget); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                    <br>

                                    <h1 class="text-lg m-2 text-gray-900 dark:text-white">
                                        <?php echo e(__('Current')); ?></h1>

                                    <ul
                                        class="flex flex-wrap items-center justify-center mb-6 text-gray-900 dark:text-white">
                                        <?php $__currentLoopData = $finance->currents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <?php echo e($current->date); ?> => <?php echo e($current->budget); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\ajatic\trabajos\spie\resources\views/exports/planning.blade.php ENDPATH**/ ?>