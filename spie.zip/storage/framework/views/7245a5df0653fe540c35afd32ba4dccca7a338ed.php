<div class="grid grid-cols-1 sm:grid-cols-12 gap-1">
    <div class="col-span-1 sm:col-span-12 bg-gray-200 dark:bg-gray-800 m-2 p-3 rounded-xl">
        <?php echo e($search); ?>

    </div>
</div>
<?php /**PATH D:\ajatic\trabajos\spie\resources\views/components/search-form.blade.php ENDPATH**/ ?>